﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace firstCoreAPPVS.Models
{
    public class Products
    {
        #region Product Properties
        public int pId { get; set; }
        public string pName { get; set; }
        public string pCategory { get; set; }
        public int pAvailableQty { get; set; }
        public int pPrice { get; set; }
        public double pDiscount { get; set; }
        public bool pIsInStock { get; set; }
        #endregion

        //this will hold all the product
        static List<Products> pList = new List<Products>();

        public List<Products> GetProductsList()
        {
            if (pList.Count == 0)
            {


                //may be connect to database and get the products, we will hardcode it for demo purpose
                pList.Add(new Products() { pId = 101, pName = "Pepsi", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 102, pName = "Coke", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 103, pName = "Maggie", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 104, pName = "Pasta", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 105, pName = "IPhone", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 106, pName = "Dell", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 107, pName = "Fossil ", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 108, pName = "Appy", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 109, pName = "Burger", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
                pList.Add(new Products() { pId = 110, pName = "Pizza", pCategory = "Cold-Drink", pAvailableQty = 40, pDiscount = 0, pIsInStock = true, pPrice = 50 });
            }
            return pList;
        }
    }
}
