﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace firstCoreAPPVS.Controllers
{
    public class TrainingController : Controller
    {
     
        public IActionResult Greet()
        {
            //collect the data from model
            //we have many ways to pass it to the view
            return View();
        }

        public IActionResult AboutTraining()
        {
            return View();
        }

        public IActionResult TrainerIntroduction()
        {
            ViewBag.firstName = "Nikhil";
            ViewBag.lastName = "Shah";
            ViewBag.city = "Mumbai";
            return View();
        }

        public IActionResult Coverage()
        {
            return View();
        }

        public IActionResult techList()
        {
            //this data is suppose to come from model
            List<string> technologies = new List<string>();
            technologies.Add(".Net");
            technologies.Add("SQL Server");
            technologies.Add("EF");
            technologies.Add("WEBAPI");
            technologies.Add("Azure");
            technologies.Add("Docker");
            technologies.Add("Containers");
            technologies.Add("Microservice");
            ViewBag.techlist = technologies;
            return View();

        }


    }
}