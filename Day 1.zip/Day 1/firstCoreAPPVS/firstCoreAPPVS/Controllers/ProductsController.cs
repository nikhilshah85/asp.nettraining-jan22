﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using firstCoreAPPVS.Models;
namespace firstCoreAPPVS.Controllers
{
    public class ProductsController : Controller
    {

        Products pModel = new Products();
       
        public IActionResult ProductList()
        {
            ViewBag.product = pModel.GetProductsList();
            return View();
        }
    }
}