﻿using System;
using System.Collections.Generic;

namespace shoppingAPP_MVC.Models
{
    public partial class Offers
    {
        public int Offerid { get; set; }
        public string Product { get; set; }
        public int? Actualrate { get; set; }
        public int? Offerprice { get; set; }
        public int? AvailableQty { get; set; }
    }
}
