﻿using System;
using System.Collections.Generic;

namespace shoppingAPP_MVC.Models
{
    public partial class Sales
    {
        public int SaleId { get; set; }
        public int? Salevalue { get; set; }
        public int? CustomerId { get; set; }
        public int? ProductId { get; set; }

        public Customers Customer { get; set; }
        public Products Product { get; set; }
    }
}
