﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace shoppingAPP_MVC.Models
{
    public partial class myshoppingDBContext : DbContext
    {
        public myshoppingDBContext()
        {
        }

        public myshoppingDBContext(DbContextOptions<myshoppingDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Customers> Customers { get; set; }
        public virtual DbSet<Offers> Offers { get; set; }
        public virtual DbSet<Products> Products { get; set; }
        public virtual DbSet<Sales> Sales { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=DESKTOP-NUK26IL\\MUMBAISERVER; database=myshoppingDB; integrated security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customers>(entity =>
            {
                entity.HasKey(e => e.CId);

                entity.ToTable("customers");

                entity.Property(e => e.CId).HasColumnName("cId");

                entity.Property(e => e.CEmail)
                    .HasColumnName("cEmail")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CMobile).HasColumnName("cMobile");

                entity.Property(e => e.CName)
                    .HasColumnName("cName")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Offers>(entity =>
            {
                entity.HasKey(e => e.Offerid);

                entity.ToTable("offers");

                entity.Property(e => e.Offerid).HasColumnName("offerid");

                entity.Property(e => e.Actualrate).HasColumnName("actualrate");

                entity.Property(e => e.AvailableQty).HasColumnName("availableQty");

                entity.Property(e => e.Offerprice).HasColumnName("offerprice");

                entity.Property(e => e.Product)
                    .HasColumnName("product")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Products>(entity =>
            {
                entity.HasKey(e => e.PId);

                entity.ToTable("products");

                entity.Property(e => e.PId).HasColumnName("pId");

                entity.Property(e => e.Disount).HasColumnName("disount");

                entity.Property(e => e.PCategory)
                    .HasColumnName("pCategory")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PIsInStock).HasColumnName("pIsInStock");

                entity.Property(e => e.PName)
                    .HasColumnName("pName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PPrice).HasColumnName("pPrice");

                entity.Property(e => e.PQty).HasColumnName("pQty");
            });

            modelBuilder.Entity<Sales>(entity =>
            {
                entity.HasKey(e => e.SaleId);

                entity.ToTable("sales");

                entity.Property(e => e.SaleId).HasColumnName("saleId");

                entity.Property(e => e.CustomerId).HasColumnName("customerId");

                entity.Property(e => e.ProductId).HasColumnName("productId");

                entity.Property(e => e.Salevalue).HasColumnName("salevalue");

                entity.HasOne(d => d.Customer)
                    .WithMany(p => p.Sales)
                    .HasForeignKey(d => d.CustomerId)
                    .HasConstraintName("fk_customer");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.Sales)
                    .HasForeignKey(d => d.ProductId)
                    .HasConstraintName("fk_products");
            });
        }
    }
}
