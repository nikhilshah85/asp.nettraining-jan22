﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_AJAX_Calls.Models;

namespace MVC_AJAX_Calls.Controllers
{
    public class AjaxCallController : Controller
    {
        PostDataFromJSONPlaceholder obj = new PostDataFromJSONPlaceholder();
        public IActionResult getPostData()
        {
            ViewBag.data = obj.GetPostData();
            return View();
        }
    }
}