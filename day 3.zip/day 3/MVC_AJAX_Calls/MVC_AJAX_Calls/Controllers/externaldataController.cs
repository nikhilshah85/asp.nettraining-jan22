﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace MVC_AJAX_Calls.Controllers
{
    public class externaldataController : Controller
    {

        public IActionResult Post()
        {
            return View();
        }

        public IActionResult Comments()
        {
            return View();
        }
        public IActionResult Photos()
        {
            return View();
        }
        public IActionResult Users()
        {
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}