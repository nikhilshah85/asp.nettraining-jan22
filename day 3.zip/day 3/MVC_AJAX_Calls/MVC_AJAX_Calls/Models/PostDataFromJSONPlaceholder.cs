﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace MVC_AJAX_Calls.Models
{
    public class PostDataFromJSONPlaceholder
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title { get; set; }
        public string body { get; set; }


        public List<PostDataFromJSONPlaceholder> GetPostData()
        {
            string url = "https://jsonplaceholder.typicode.com/posts";
            HttpClient client = new HttpClient();

            //differnt browsers, will make calls in differnt formats, eg. IE makes call in json, chrome makes call in xml by default
            //we do not want this difference, we will set a common format for the calling environment

            client.DefaultRequestHeaders.Accept.Clear(); //clear the defaults
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));


            var call = client.GetAsync(url);
            //we now need to check, if the call is getting a success of error
            var msg = call.Result;

            List<PostDataFromJSONPlaceholder> data = null;
            if (msg.IsSuccessStatusCode)
            {
                //load the data in local variables
                var read = msg.Content.ReadAsAsync<List<PostDataFromJSONPlaceholder>>();
                read.Wait();
                data = read.Result;
            }
            return data;

        }
    }
}







