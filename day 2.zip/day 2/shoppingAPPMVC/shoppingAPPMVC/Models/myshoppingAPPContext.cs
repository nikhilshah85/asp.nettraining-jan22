﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace shoppingAPPMVC.Models
{
    public partial class myshoppingAPPContext : DbContext
    {
        public myshoppingAPPContext()
        {
        }

        public myshoppingAPPContext(DbContextOptions<myshoppingAPPContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Customers> Customers { get; set; }
        public virtual DbSet<Products> Products { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=DESKTOP-NUK26IL\\MUMBAISERVER; database=myshoppingAPP; integrated security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customers>(entity =>
            {
                entity.HasKey(e => e.CId);

                entity.ToTable("customers");

                entity.Property(e => e.CId).HasColumnName("cId");

                entity.Property(e => e.CCity)
                    .HasColumnName("cCity")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CName)
                    .HasColumnName("cName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CWalletBalance).HasColumnName("cWalletBalance");
            });

            modelBuilder.Entity<Products>(entity =>
            {
                entity.HasKey(e => e.Pid);

                entity.ToTable("products");

                entity.Property(e => e.Pid).HasColumnName("pid");

                entity.Property(e => e.PAvailableQty).HasColumnName("pAvailableQty");

                entity.Property(e => e.PCategory)
                    .HasColumnName("pCategory")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PIsInStock).HasColumnName("pIsInStock");

                entity.Property(e => e.PName)
                    .HasColumnName("pName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PPrice).HasColumnName("pPrice");
            });
        }
    }
}
