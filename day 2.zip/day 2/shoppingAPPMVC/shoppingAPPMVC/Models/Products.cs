﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace shoppingAPPMVC.Models
{
    public partial class Products
    {
        public int Pid { get; set; }

        [Display(Name ="Product Name")]
        [Required(AllowEmptyStrings =false,ErrorMessage ="Product Name is Mandatory")]
        [StringLength(25,MinimumLength =3,ErrorMessage ="Product Name to be between 3 and 25 characters only")]        
        public string PName { get; set; }

        [Display(Name = "Category")]
        [Required(AllowEmptyStrings =false,ErrorMessage ="Please mention the category of product")]
        public string PCategory { get; set; }

        [Display(Name = "Qty")]
        [System.ComponentModel.DataAnnotations.Range(5,100,ErrorMessage ="Qty should be between 5 and 100 only")]
        public int? PAvailableQty { get; set; }
        [Display(Name = "Price")]
        [Range(10,2500,ErrorMessage ="Price should be between 10 and 2500 range only")]

        public int? PPrice { get; set; }
        [Display(Name = "In Stock")]        
        public bool? PIsInStock { get; set; }
    }
}
