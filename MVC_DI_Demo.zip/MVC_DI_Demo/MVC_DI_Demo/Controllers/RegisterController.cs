﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_DI_Demo.Models;
namespace MVC_DI_Demo.Controllers
{
    public class RegisterController : Controller
    {
        Training _tr; //why cant we use the object of training created in other controler

        public RegisterController(Training trObj)
        {
            _tr = trObj;
        }
        public IActionResult Index()
        {
            ViewBag.message = _tr.GreetParticapants();
            return View();
        }
    }
}