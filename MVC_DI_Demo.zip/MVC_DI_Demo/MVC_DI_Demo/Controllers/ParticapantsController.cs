﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_DI_Demo.Models;
namespace MVC_DI_Demo.Controllers
{
    public class ParticapantsController : Controller
    {
        Training _tr;

        public ParticapantsController(Training trObj)
        {
            _tr = trObj;
        }
        public IActionResult Index()
        {
            ViewBag.message = _tr.GreetParticapants();
            return View();
        }
    }
}