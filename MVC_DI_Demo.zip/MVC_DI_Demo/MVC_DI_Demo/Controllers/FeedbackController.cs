﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_DI_Demo.Models;
namespace MVC_DI_Demo.Controllers
{
    public class FeedbackController : Controller
    {
       // Training _tr;  = new Training(); again create the object
        public IActionResult Index()
        {
            //lets say user will come to this method and go away, 
            //but the object of training was still created, it may be a heavy object, with DB
            return View();
        }

        public IActionResult Feedback(Training trObj)
        {
            Training _tr = trObj; //this will be auto created on demand
            //thiis is the only method in whole controller, 
            //where we need the training object, user may not client the page
            ViewBag.message = _tr.GreetParticapants();
            return View();
        }
    }
}