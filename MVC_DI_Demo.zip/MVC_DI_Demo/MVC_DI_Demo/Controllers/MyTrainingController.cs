﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_DI_Demo.Models;
namespace MVC_DI_Demo.Controllers
{
    public class MyTrainingController : Controller
    {
        // Training tr = new Training(); this is the problem
        //who will destroy the object ??
        //300 request coming per minute

        Training _tr;  //use _ for nameing

        public MyTrainingController(Training trObj)
        {
            _tr = trObj;
            //trObj is the reference of of object creaed by server, now u can use _tr in this class
        }


        
        public IActionResult Index()
        {
            ViewBag.message = _tr.GreetParticapants();
            return View();
        }


    }
}