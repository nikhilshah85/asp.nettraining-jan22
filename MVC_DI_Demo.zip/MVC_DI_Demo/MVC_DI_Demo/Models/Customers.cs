﻿using System;
using System.Collections.Generic;

namespace MVC_DI_Demo.Models
{
    public partial class Customers
    {
        public Customers()
        {
            Sales = new HashSet<Sales>();
        }

        public int CId { get; set; }
        public string CName { get; set; }
        public string CEmail { get; set; }
        public long? CMobile { get; set; }

        public ICollection<Sales> Sales { get; set; }
    }
}
