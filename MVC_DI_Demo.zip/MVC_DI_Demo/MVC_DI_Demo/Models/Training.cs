﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_DI_Demo.Models
{
    public class Training
    {
        public int tId { get; set; }
        public string tName { get; set; }
        public string tDays { get; set; }
        //20 more properties
        public string GreetParticapants()
        {
            return "Hello and welcome to training, Model";
        }

        //10 more methods, CRUD, sort, filter etc..
    }
}
