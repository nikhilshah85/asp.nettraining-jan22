﻿using System;
using System.Collections.Generic;

namespace MVC_DI_Demo.Models
{
    public partial class Products
    {
        public Products()
        {
            Sales = new HashSet<Sales>();
        }

        public int PId { get; set; }
        public string PName { get; set; }
        public string PCategory { get; set; }
        public int? PQty { get; set; }
        public int? PPrice { get; set; }
        public bool? PIsInStock { get; set; }
        public int? Disount { get; set; }

        public ICollection<Sales> Sales { get; set; }
    }
}
