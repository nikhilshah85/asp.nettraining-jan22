﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_Repository.Models
{
    public class EmployeeModel
    {
        public int empNo { get; set; }
        public string empName { get; set; }
        public int empSalary { get; set; }
        public bool empIsPermenant { get; set; }
        public string empDesignation { get; set; }
    }
}
