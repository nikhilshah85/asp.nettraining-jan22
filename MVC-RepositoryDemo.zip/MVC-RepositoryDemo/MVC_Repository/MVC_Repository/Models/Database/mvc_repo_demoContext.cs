﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
namespace MVC_Repository.Models.Database
{
    public partial class mvc_repo_demoContext : DbContext
    {
        IConfiguration _configuration;
        public mvc_repo_demoContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public mvc_repo_demoContext(DbContextOptions<mvc_repo_demoContext> options)
            : base(options)
        {
        }

        public virtual DbSet<EmployeeDataSql> EmployeeDataSql { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            {
                if (!optionsBuilder.IsConfigured)
                {
                    //optionsBuilder.UseSqlServer();
                    optionsBuilder.UseSqlServer(_configuration.GetConnectionString("mysqlserver"));
                }
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EmployeeDataSql>(entity =>
            {
                entity.HasKey(e => e.EmployeeNo);

                entity.ToTable("EmployeeDataSQL");

                entity.Property(e => e.EmployeeNo)
                    .HasColumnName("employeeNo")
                    .ValueGeneratedNever();

                entity.Property(e => e.EmployeeDesignation)
                    .HasColumnName("employeeDesignation")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.EmployeeIsPermenant).HasColumnName("employeeIsPermenant");

                entity.Property(e => e.EmployeeName)
                    .HasColumnName("employeeName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.EmployeeSalary).HasColumnName("employeeSalary");
            });
        }
    }
}
