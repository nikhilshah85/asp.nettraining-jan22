﻿using System;
using System.Collections.Generic;

namespace MVC_Repository.Models.Database
{
    public partial class EmployeeDataSql
    {
        public int EmployeeNo { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeDesignation { get; set; }
        public int? EmployeeSalary { get; set; }
        public bool? EmployeeIsPermenant { get; set; }
    }
}
