﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_Repository.Repository;
using MVC_Repository.Models;
namespace MVC_Repository.Controllers
{
    public class EmployeeController : Controller
    {
        IEmployeeRepository _emp;

        public EmployeeController(IEmployeeRepository empObjRef)
        {
            _emp = empObjRef;
        }

        public IActionResult EmployeeList()
        {
            return View(_emp.GetEmployeeList());
        }
        //this method will give you the form, you will fill the form and submit
        public IActionResult AddEmployee()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddEmployee(EmployeeModel newEmp)
        {
            ViewBag.addMessage = _emp.AddEmployee(newEmp);
            return View();
        }

       
    }
}