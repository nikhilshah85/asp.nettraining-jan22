﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_Repository.Models;
namespace MVC_Repository.Repository
{
   public interface IEmployeeRepository
    {
        List<EmployeeModel> GetEmployeeList();
        EmployeeModel GetEmpbyId(int id);
        string AddEmployee(EmployeeModel newEmp);
        string updateEmployee(EmployeeModel updates);
        string DeleteEmployee(int id);
        int totalEmployees();
    }
}
