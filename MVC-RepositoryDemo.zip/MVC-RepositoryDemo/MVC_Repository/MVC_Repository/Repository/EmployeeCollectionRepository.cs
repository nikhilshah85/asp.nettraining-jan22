﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_Repository.Models;
namespace MVC_Repository.Repository
{
    public class EmployeeCollectionRepository : IEmployeeRepository
    {
        #region in memory collection 
        static List<EmployeeModel> eList = new List<EmployeeModel>()
        {
            new EmployeeModel(){empNo=101, empName="Karan", empDesignation="Sales", empSalary=5000, empIsPermenant=true},
            new EmployeeModel(){empNo=102, empName="Rohan", empDesignation="Sales", empSalary=5000, empIsPermenant=true},
            new EmployeeModel(){empNo=103, empName="Mohan", empDesignation="Sales", empSalary=5000, empIsPermenant=true},
        };
        #endregion

        #region Interface methods - Repository
        public string AddEmployee(EmployeeModel newEmp)
        {
            //validations and formatting to be done here
            eList.Add(newEmp);
            return "Employee Added to Collection";
        }

        public string DeleteEmployee(int id)
        {
            eList.Remove(eList.Find(e => e.empNo == id));
            return "Emoyee deleted from Collection";
        }

        public EmployeeModel GetEmpbyId(int id)
        {
            return eList.Find(e => e.empNo == id);
        }

        public List<EmployeeModel> GetEmployeeList()
        {
            return eList;
        }

        public int totalEmployees()
        {
            return eList.Count;
        }

        public string updateEmployee(EmployeeModel updates)
        {
            var emp = eList.Find(e => e.empNo == updates.empNo);
            emp.empName = updates.empName;
            emp.empDesignation = updates.empDesignation;
            emp.empSalary = updates.empSalary;
            return "Employee Updated in collection";
        }
        #endregion
    }
}
