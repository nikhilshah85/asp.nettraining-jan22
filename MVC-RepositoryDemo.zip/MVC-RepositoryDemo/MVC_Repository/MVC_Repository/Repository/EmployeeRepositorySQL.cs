﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_Repository.Models;
using MVC_Repository.Models.Database;
namespace MVC_Repository.Repository
{
    public class EmployeeRepositorySQL : IEmployeeRepository
    {
        #region database context
        mvc_repo_demoContext _db;

        public EmployeeRepositorySQL(mvc_repo_demoContext _dbRefObj)
        {
            _db = _dbRefObj;
        }
        #endregion

        public string AddEmployee(EmployeeModel newEmp)
        {
            //as per interface, we need to pass the model from front end,
            //but in the backend we need to save it to a table
            EmployeeDataSql newEmployee = new EmployeeDataSql();
            newEmployee.EmployeeNo = newEmp.empNo;
            newEmployee.EmployeeName = newEmp.empName;
            newEmployee.EmployeeDesignation = newEmp.empDesignation;
            newEmployee.EmployeeSalary = newEmp.empSalary;
            newEmployee.EmployeeIsPermenant = newEmp.empIsPermenant;

            _db.EmployeeDataSql.Add(newEmployee);
            _db.SaveChanges(); //commit to database

            return "Employee Added To Database";

        }

        public string DeleteEmployee(int id)
        {
            //u can use linq or lambda or ado.net
            var emp = (from e in _db.EmployeeDataSql
                      where e.EmployeeNo == id
                      select e).Single();

            _db.EmployeeDataSql.Remove(emp);
            _db.SaveChanges();
            return "Employee Deleted from Database";
        }

        public EmployeeModel GetEmpbyId(int id)
        {
            var emp = (from e in _db.EmployeeDataSql
                       where e.EmployeeNo == id
                       select e).Single();

            EmployeeModel empModel = new EmployeeModel(); //use DI instead
            empModel.empNo = emp.EmployeeNo;
            empModel.empName = emp.EmployeeName;
            empModel.empDesignation = emp.EmployeeDesignation;
            empModel.empSalary =Convert.ToInt32(emp.EmployeeSalary);
            empModel.empIsPermenant = Convert.ToBoolean(emp.EmployeeIsPermenant);

            return empModel;

        }

        public List<EmployeeModel> GetEmployeeList()
        {
            var allEmp = _db.EmployeeDataSql.ToList();
            List<EmployeeModel> eList = new List<EmployeeModel>();
            foreach (var emp in allEmp)
            {
                EmployeeModel empModel = new EmployeeModel(); //use DI instead
                empModel.empNo = emp.EmployeeNo;
                empModel.empName = emp.EmployeeName;
                empModel.empDesignation = emp.EmployeeDesignation;
                empModel.empSalary = Convert.ToInt32(emp.EmployeeSalary);
                empModel.empIsPermenant = Convert.ToBoolean(emp.EmployeeIsPermenant);
                eList.Add(empModel);
            }
            return eList;
        }

        public int totalEmployees()
        {
            return _db.EmployeeDataSql.Count();
        }

        public string updateEmployee(EmployeeModel updates)
        {
            var newEmployee = (from e in _db.EmployeeDataSql
                       where e.EmployeeNo == updates.empNo
                       select e).Single();

            newEmployee.EmployeeNo = updates.empNo;
            newEmployee.EmployeeName = updates.empName;
            newEmployee.EmployeeDesignation = updates.empDesignation;
            newEmployee.EmployeeSalary = updates.empSalary;
            newEmployee.EmployeeIsPermenant = updates.empIsPermenant;

            _db.SaveChanges();

            return "Employee Updated in database";

        }
    }
}
