﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_Repository.Models;

namespace MVC_Repository.Repository
{
    public class EmployeeRepoNoSQL : IEmployeeRepository
    {
        //for demo we will have a dummy list collection for display, u will have ur nosql conn
        List<EmployeeModel> empList = new List<EmployeeModel>()
        {
            new EmployeeModel(){ empNo = 701, empName = "Shawn", empDesignation="CEO", empIsPermenant=true, empSalary=250000}
        };

        public string AddEmployee(EmployeeModel newEmp)
        {
            empList.Add(newEmp);

            return "Added to NoSQL";
        }

        public string DeleteEmployee(int id)
        {
            throw new NotImplementedException();
        }

        public EmployeeModel GetEmpbyId(int id)
        {
            throw new NotImplementedException();
        }

        public List<EmployeeModel> GetEmployeeList()
        {
            return empList;
        }

        public int totalEmployees()
        {
            throw new NotImplementedException();
        }

        public string updateEmployee(EmployeeModel updates)
        {
            throw new NotImplementedException();
        }
    }
}
