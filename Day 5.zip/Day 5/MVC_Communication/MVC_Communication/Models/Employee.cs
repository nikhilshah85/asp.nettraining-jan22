﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_Communication.Models
{
    public class Employee
    {
        public int empNo { get; set; }
        public string empName { get; set; }
        public double empSalary { get; set; }
        public bool empIsPermenant { get; set; }
        public string empDesignation { get; set; }
        public int empManagerNo { get; set; }
        public string empDepartment { get; set; }
        public string empCity { get; set; }

       static List<Employee> eList = new List<Employee>()
        {
            new Employee(){ empNo = 101, empName = "Smruti", empCity = "Mumbai", empDepartment = "Training", empDesignation= "HR", empIsPermenant=true, empManagerNo=45445, empSalary=75000}
        };

        
        public List<Employee> GetEmployeesList()
        {
            return eList;
        }

        public string AddEmployee(Employee newEmp)
        {
            //do ur validations
            if (newEmp.empSalary < 25000)
            {
                throw new Exception("Employee Salary needs to be minimum 25000");
            }
            eList.Add(newEmp);
            return "Employee Added Successfully";
        }

    }
}
