﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_Communication.Models;
namespace MVC_Communication.Controllers
{
    public class EmployeeController : Controller
    {
        Employee empObj = new Employee();

        public IActionResult EmployeeList()
        {

            return View(empObj.GetEmployeesList());
        }


        public IActionResult AddEmployee()
        {
            ViewBag.hasError = false;
            return View();
        }

        //very lengthy way, not recommended

        //[HttpPost]
        //public IActionResult AddEmployee(int eNo, string eName, double eSalary, bool isPermenant,string eDesignation,  int eManager,string eDeptName, string eCity )
        //{
        //    Employee newEmp = new Employee()
        //    {
        //        empNo = eNo,
        //        empName = eName,
        //        empSalary = eSalary,
        //        empIsPermenant = isPermenant,
        //        empDepartment = eDeptName,
        //        empDesignation = eDesignation
        //    };
        //    empObj.AddEmployee(newEmp);
        //    return View();
        //}

        [HttpPost]
        public IActionResult AddEmployee(Employee newEmpobj)
        {
            ViewBag.hasError = false;
            try
            {              

                empObj.AddEmployee(newEmpobj);
                ViewBag.hasError = false;
            }
            catch (Exception es)
            {
                ViewBag.hasError = true;
                ViewBag.errMessage = es.Message;
            }
            //  return Redirect("https://localhost:44386/employee/employeelist"); //redirect to any where - eg. to google as well - even outside ur application
         //   RedirectToAction("Index", "Home"); //redirect anywhere only within the application
          return  RedirectToAction("EmployeeList"); 
        }


        public IActionResult Index()
        {
            return View();
        }
    }
}