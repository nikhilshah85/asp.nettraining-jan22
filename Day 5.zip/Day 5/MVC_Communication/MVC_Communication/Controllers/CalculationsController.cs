﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace MVC_Communication.Controllers
{
    public class CalculationsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Greetings()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Greetings(string guestName)
        {
            ViewBag.message = "Hello and Welcome " + guestName;
            return View();
        }


        public IActionResult Calculate()
        {
            ViewBag.display = false;
            return View();
        }

        [HttpPost]
        public IActionResult Calculate(int firstNumber, int secondNumber)
        {

            ViewBag.display = true;
            if (firstNumber < secondNumber)
            {
                ViewBag.haserror = true;
                ViewBag.errMessage = "First number has to be greater than second Number";
                return View();
            }
            if (firstNumber < 0 || secondNumber < 0)
            {
                ViewBag.haserror = true;
                ViewBag.errMessage = "Please Enter Only Positive numbers";
                return View();
            }
            if (secondNumber == 0)
            {
                ViewBag.haserror = true;
                ViewBag.errMessage = "This will result in a number division by 0, which cannot be proccessed";
                return View();
            }
            else
            {
                ViewBag.haserror = false;
              
                ViewBag.addition = firstNumber + secondNumber;
                ViewBag.subtraction = firstNumber - secondNumber;
                ViewBag.multipliction = firstNumber * secondNumber;
                ViewBag.division = firstNumber / secondNumber;
            }
            return View();
        }


    }
}