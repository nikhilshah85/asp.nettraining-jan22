﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Identity_Demo.Controllers
{
    [Authorize]
    public class shoppingController : Controller
    {
        [AllowAnonymous]
       public IActionResult Productlist()
        {
            return View();
        }

        public IActionResult Cart()
        {
            return View();
        }

        public IActionResult Profile()
        {
            return View();
        }
        public IActionResult Wallet()
        {
            return View();
        }
    }
}