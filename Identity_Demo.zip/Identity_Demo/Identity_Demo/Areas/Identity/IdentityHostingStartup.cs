﻿using System;
using Identity_Demo.Areas.Identity.Data;
using Identity_Demo.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: HostingStartup(typeof(Identity_Demo.Areas.Identity.IdentityHostingStartup))]
namespace Identity_Demo.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                services.AddDbContext<Identity_DemoContext>(options =>
                    options.UseSqlServer(
                        context.Configuration.GetConnectionString("Identity_DemoContextConnection")));

                services.AddDefaultIdentity<Identity_DemoUser>()
                    .AddEntityFrameworkStores<Identity_DemoContext>();
            });
        }
    }
}